# NOTICE

MASSIVE was created by translating and localizing the English text data from SLURP into 50 languages. Additionally, some of the text data from SLURP is included as part of MASSIVE. SLURP is licensed under CC BY 4.0. The license can be found here:

> [https://github.com/pswietojanski/slurp/blob/master/LICENSE.txt](https://github.com/pswietojanski/slurp/blob/master/LICENSE.txt)

For additional information on SLURP, please see [their paper](https://aclanthology.org/2020.emnlp-main.588.pdf).